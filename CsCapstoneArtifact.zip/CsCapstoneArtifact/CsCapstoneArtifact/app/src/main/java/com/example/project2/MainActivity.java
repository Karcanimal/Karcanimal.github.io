package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import at.favre.lib.crypto.bcrypt.BCrypt;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Button initializations
    private Button login_button;
    private Button create_account_button;
    private EditText username_edittext;
    private EditText password_edittext;
    private DBHelper dbHelper;

    // Login Error Message
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Button listening
        login_button = findViewById(R.id.login_button);
        username_edittext = findViewById(R.id.username_edittext);
        password_edittext = findViewById(R.id.password_edittext);
        create_account_button = findViewById(R.id.create_account_button);
        dbHelper = new DBHelper(this);

        // Handles Login Buttons clicks
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = username_edittext.getText().toString();
                String password = password_edittext.getText().toString();

                // If successful goes to the main screen
                if (dbHelper.checkUser(username, password)) {
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    startActivity(intent);
                } else {
                    // Clear the input fields
                    username_edittext.getText().clear();
                    password_edittext.getText().clear();

                    // Show a Toast message for incorrect username or password
                    showToast("Incorrect username or password");
                }
            }
        });

        // Handles Create Account button clicks
        create_account_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the registration here
                String newUsername = username_edittext.getText().toString();
                String newPassword = password_edittext.getText().toString();

                // Show a dialog before inserting data into the database
                showConfirmationDialog(newUsername, newPassword);
            }
        });
    }

    // Method to show a confirmation dialog
    private void showConfirmationDialog(final String newUsername, final String newPassword) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation");
        builder.setMessage("Are you sure you want to create an account?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Insert userInput into the SQLite database
                try {
                    insertDataIntoDatabase(newUsername, hashPassword(newPassword));
                } catch (Exception e) {
                    e.printStackTrace();
                    showToast("Failed to create an account");
                }
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing or handle the cancellation
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Adds users into the Database
    private void insertDataIntoDatabase(String newUser, String newPass) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            // Use parameterized query to prevent SQL injection
            String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            db.execSQL(sql, new String[]{newUser, newPass});

            username_edittext.getText().clear();
            password_edittext.getText().clear();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception, e.g., log it or show an error message to the user
        } finally {
            // Close the database to release resources
            db.close();
        }
    }

    // Hash the password using bcrypt
    private String hashPassword(String password) {
        return BCrypt.withDefaults().hashToString(12, password.toCharArray());
    }

    // DataBase handler class
    public class DBHelper extends SQLiteOpenHelper {
        // Database variables
        private static final String DB_NAME = "THE_COUNTER-DB.db";
        private static final int DB_VERSION = 1;
        private static final String TABLE_NAME = "users";
        private static final String COL_ID = "id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";

        public DBHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE " + TABLE_NAME + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT, " +
                    COL_PASSWORD + " TEXT);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

        // Verifies users in the DataBase
        public boolean checkUser(String username, String password) {
            SQLiteDatabase db = this.getReadableDatabase();

            try (Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " +
                    COL_USERNAME + "=?", new String[]{username})) {
                if (cursor.moveToFirst()) {
                    int passwordColumnIndex = cursor.getColumnIndex(COL_PASSWORD);
                    if (passwordColumnIndex != -1) {
                        String storedPassword = cursor.getString(passwordColumnIndex);
                        return BCrypt.verifyer().verify(password.toCharArray(), storedPassword).verified;
                    } else {
                        // Handle the case where COL_PASSWORD column is not found
                        return false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                // Close the database to release resources
                db.close();
            }

            return false;
        }

    }
}
